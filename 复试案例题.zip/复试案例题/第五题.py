#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import talib.abstract as ta

io = r'sz50.xlsx'
data_all = pd.read_excel(io, sheet_name=None, index_col='datetime')
key1 = pd.DataFrame(data_all.keys())
key2 = np.array(key1)
n = 0
symbol = []
data_dict = {}
def stock(n):
    stock_n = str(key2[n])
    return symbol.append(stock_n[2:13])

for n in range(50):
    stock(n)
    n = n + 1

for s in symbol:
    data = pd.read_excel(io, sheetname=s, index_col='datetime')
    if data.empty == True: # 处理空白表
        pass
    else:
        data_dict[s] = data.loc['2017-01-03':'2017-11-20']

PN = pd.Panel(data_dict)
MI = PN.to_frame()

# 处理缺失值
if PN.isnull().values.any() == True:
    PN.dropna(inplace=True)

df_ma = pd.DataFrame({name: ta.MA(value, 5) for name, value in PN.iteritems()})
pn_macd = pd.Panel({name: ta.MACD(value) for name, value in PN.iteritems()})
df_macd = pn_macd.transpose(2,1,0).to_frame()
df_macd.to_csv('第五题运行结果.csv')
print(df_macd)

