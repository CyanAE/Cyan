#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import talib
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

io = r'sz50.xlsx'
data = pd.read_excel(io, sheet_name='600036.XSHG', index_col = 'datetime')
frame = pd.DataFrame(data)
dataclose1 = frame['close']
dataclose2 = np.array(dataclose1)
ma10 = talib.MA(dataclose2, timeperiod=10)

data2 = pd.read_excel(io, sheet_name='600036.XSHG')
frame2 = pd.DataFrame(data2)
datetime1 = frame2['datetime']
datetime2 = np.array(datetime1)

series = pd.Series(ma10, datetime2)

x = datetime2
y_1 = dataclose1
y_2 = ma10
plt.plot(x,y_1,color='#1874CD')
plt.plot(x,y_2,color='#EE9A49')
plt.show()
