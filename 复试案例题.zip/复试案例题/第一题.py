#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import talib
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

io = r'sz50.xlsx'
data = pd.read_excel(io, sheet_name=None, index_col='datetime')
print(data.keys())
