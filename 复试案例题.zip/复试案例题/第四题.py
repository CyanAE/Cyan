#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import talib
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 第一问
io = r'sz50.xlsx'
data = pd.read_excel(io, sheet_name=None, index_col='datetime')
key1 = pd.DataFrame(data.keys())
key2 = np.array(key1)
n = 0
for n in range(50):
    stock = str(key2[n])
    stock_name = stock[2:13]
    data_n = pd.read_excel(io, sheet_name=stock_name, index_col='datetime')
    frame_n = pd.DataFrame(data_n)
    if frame_n.empty == True: # 处理空白表格
        pass
    else:
        dataclose_n1 = frame_n['close']
        dataclose_n2 = np.array(dataclose_n1)
        rocr100_n = talib.ROCR100(dataclose_n2, timeperiod=5)
        Rocr100 = pd.DataFrame(rocr100_n)
        # print(Rocr100)
        # print(n)
        n = n + 1

# 第二问
io = r'D:\sz50.xlsx'
data = pd.read_excel(io, sheet_name=None, index_col='datetime')
key1 = pd.DataFrame(data.keys())
key2 = np.array(key1)
n = 0
def stock_name(n): # 得到第n个表格名
    stock = str(key2[n])
    return stock[2:13]

def rocr100(n):
    stock_name(n)
    data_n = pd.read_excel(io, sheet_name=stock_name(n), index_col='datetime')
    frame_n = pd.DataFrame(data_n)
    if frame_n.empty == True:
        pass
    else:
        dataclose_n1 = frame_n['close']
        dataclose_n2 = np.array(dataclose_n1)
        return talib.ROCR100(dataclose_n2, timeperiod=5)

def datetime(n):
    stock_name(n)
    time = pd.read_excel(io, sheet_name=stock_name(n))
    frame = pd.DataFrame(time)
    datetime1 = frame['datetime']
    return np.array(datetime1)

def x(n):
    return datetime(n)
def y(n):
    return rocr100(n)

for n in range(5):
    stock_name(n)
    rocr100(n)
    datetime(n)
    series = pd.Series(rocr100(n), datetime(n))
    x(n)
    y(n)
    n = n + 1

plt.plot(x(0),y(0),color='#1874CD',label=stock_name(0))
plt.plot(x(1),y(1),color='#FF83FA',label=stock_name(1))
plt.plot(x(2),y(2),color='#9A32CD',label=stock_name(2))
plt.plot(x(3),y(3),color='#4D4D4D',label=stock_name(3))
plt.plot(x(4),y(4),color='#00EE00',label=stock_name(4))
plt.legend()
plt.show()
